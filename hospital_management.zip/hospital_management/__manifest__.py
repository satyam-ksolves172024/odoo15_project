{
    'name': 'Hospital Management',
    'version': '1.0.0',
    'author':'Author',
    'sequence':-100,
    'application': True,
    'category':'category',
    'summary':'hospital management',
    'description':'learning to create a module',

    'data':[
        'security/ir.model.access.csv',
'views/tags.xml',
        'views/menu_items_actions.xml',
'views/appointment.xml',
'views/menu_items.xml',

    ],


}