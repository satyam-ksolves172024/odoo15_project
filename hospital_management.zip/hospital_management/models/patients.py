# -*- coding: utf-8 -*-
from odoo import models, fields, api


class PatientTable(models.Model):
    _name = 'patient.table'
    _rec_name = 'name'
    name = fields.Char(string='Name', required=True)
    photo = fields.Binary(string='Image')
    age = fields.Integer(string='Age', compute='_compute_age')
    gender = fields.Selection([('male', 'Male'), ('female', 'Female'), ('others', 'Others')], string='Gender')
    patient_dob = fields.Date(string="Date of Birth")

    ref = fields.Char(string='ref', default="12345")

    student_blood_group = fields.Selection(
        [('A+', 'A+ve'), ('A-', 'A-ve'),
         ('B+', 'B+ve'), ('B-', 'B-ve'),
         ('O+', 'O+ve'), ('O-', 'O-ve'),
         ('AB+', 'AB+ve'), ('AB-', 'AB-ve')],
        string='Blood Group'
    )

    @api.depends('patient_dob')
    def _compute_age(self):
        from datetime import date

        today = date.today()
        for rec in self:

            if not rec.patient_dob:
                rec.patient_dob = today
            rec.age = today.year - rec.patient_dob.year
