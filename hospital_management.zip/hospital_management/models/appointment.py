# -*- coding: utf-8 -*-
from odoo import models, fields, api


class AppointmentTable(models.Model):
    _name = 'appointment.table'
    _rec_name = "patient_id"
    patient_id = fields.Many2one("patient.table", string="patient")
    gender = fields.Selection(related="patient_id.gender")

    appointment_date = fields.Date(string="Appointment Date", default=fields.Date.context_today)
    appointment_time = fields.Datetime(string="appointment time", default=fields.Datetime.now)
    age = fields.Integer(string='Age', related="patient_id.age")
    ref = fields.Char(string="Reference")
    # doctor_id = fields.Many2one('rec.users',string="Doctor Id")
    pharmacy_lines_ids = fields.One2many("pharmacy.lines", "appointment_id", string="Pharmacy Lines")
    hide_button = fields.Boolean(string="Hide sales price")
    tags = fields.Many2many('patient.tag', string="Tag")

    state = fields.Selection(selection=[
        ('draft', 'Draft'),
        ('in_progress', 'In Progress'),
        ('cancel', 'Cancelled'),
        ('done', 'Done'),
    ], string='Status', required=True, readonly=True, copy=False,
        tracking=True, default='draft')

    def button_in_progress(self):
        self.write({
            'state': "in_progress"
        })
    @api.onchange('patient_id')
    def onchange_patient_id(self):
        # for rec in self:
        # if not self.patient_id:
        #     self.ref = self.patient_id.ref
        self.ref = self.patient_id.ref



