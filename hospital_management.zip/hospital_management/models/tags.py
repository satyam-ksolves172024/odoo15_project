# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Patienttags(models.Model):
    _name = "patient.tag"
    _description = "tag model including various like doctor patient attender etc."
    _rec_name = "tag_name"

    tag_name = fields.Char(string="Tags", required=True)
    active = fields.Boolean(string="Status", default=True)
    color = fields.Integer(string="Color")
