from odoo import models, fields, api
class pharmacy_lines(models.Model):
    _name = "pharmacy.lines"

    # product_id = fields.Many2one("product.product", string="Product Id")
    price_unit = fields.Float(string="Price Unit")
    qty = fields.Integer(string="Quantity")

    appointment_id = fields.Many2one("appointment.table", string="Appointment ID")