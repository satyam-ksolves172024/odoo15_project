from odoo import models, fields, api

class ExampleResultWizard(models.TransientModel):
    _name = 'example.result.wizards'
    _description = 'Example Result Wizard'

    result = fields.Char(string="Result")
