{
    'name': 'School Management',
    'version': '1.0.0',
    'author':'Author',
    'sequence':-100,
    'application': True,
    'category':'category',
    'summary':'school management',
    'description':'learning to create a module',
    'depends':['sale'],
    'data':[
        'security/ir.model.access.csv',
        'views/prediction.xml',
        'views/wizard_view.xml',
        'views/ml_models_views.xml',
'views/add_student.xml',
'views/sales_data_view.xml',
        'views/student_views.xml',


    ],


}