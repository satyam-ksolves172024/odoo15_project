from odoo import models,fields,_

class SpamClassifier(models.Model):
    _name = 'spam.table'

    target = fields.Char(string='Name', required=True)

    text = fields.Char(string='Spam Text', required=True)