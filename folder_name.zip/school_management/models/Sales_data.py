from odoo import models, fields, api

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    @api.model
    def predict_sales(self):
        ml_model = self.env['ml.model'].search([], limit=1)
        prediction = ml_model.predict([self.amount_total])
        return prediction
