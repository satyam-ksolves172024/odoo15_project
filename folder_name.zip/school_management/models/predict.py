from odoo import api,models,fields


class predictModel(models.Model):
    _name = "prediction.model"
    # _rec_name = 'input_text'

    # input_text = fields.Char(string='Input Text')
    # prediction = fields.Char(string='Prediction')
    #
    # ml_model_id = fields.Many2one('ml.model', string="Ml Model Id")
    # name_1 = fields.char(related='ml_model_id.name')
