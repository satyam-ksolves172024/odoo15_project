from odoo import models, fields, api


class ExampleModel(models.TransientModel):
    _name = 'example.model'
    _description = 'Example Model'

    result = fields.Char(string="Result")

    # @api.model
    def execute_button_action(self):
        # Perform some operations
        result = "This is the result of the operation"

        # Create a new record in the wizards to display the result
        wizard = self.env['example.result.wizards'].create({'result': result})

        # Return an action to open the wizards
        return {
            'type': 'ir.actions.act_window',
            'name': 'Result Wizard',
            'view_mode': 'form',
            'res_model': 'example.result.wizards',
            'res_id': wizard.id,
            'target': 'new'
        }
