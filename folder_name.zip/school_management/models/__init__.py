from . import students,Sales_data,Spam_data,ml_model,example_file,predict
