from odoo import models, fields, api
import joblib
import pandas as pd


class MLModel(models.Model):
    _name = 'ml.model'
    _description = 'ML Model'

    # name = fields.Char(string='Name')
    # predict_ids = fields.One2many("prediction.model", "ml_model_id", string="Prediction IDs")
    # li = fields.Char(string="Input text", compute="_func")
    # name_1 = fields.char(related='ml_model_id.name')
    input_text = fields.Text(string='Input Text')
    prediction = fields.Char(string='Prediction')

    # @api.depends('predict_ids')
    # def _func(self):
    #     for ids in self:
    #         ids.li = ','.join(val.input_text for val in ids.predict_ids)

    # def load_model(self):
    #     self.model = joblib.load('/home/satyamksi216/training_python/python/model.pkl')
    #     self.vectorizer = joblib.load('/home/satyamksi216/training_python/python/vectorizer.pkl')

    def make_prediction(self):
        model = joblib.load('/home/satyamksi216/training_python/python/model.pkl')
        vectorizer = joblib.load('/home/satyamksi216/training_python/python/vectorizer.pkl')
        input_text = self.input_text

        # Transform the input text from odoo
        input_vector = vectorizer.transform([input_text])

        # Make prediction
        prediction = model.predict(input_vector)

        # Update the record with the prediction


        self.prediction = "spam" if prediction[0]==1 else "not spam"

        # self.prediction = prediction[0]
